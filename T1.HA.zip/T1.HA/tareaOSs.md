Tarea 1 
Alumno Hernán Aldana.
Profesor Sebastián Saez.
Ramo: Sistemas Operativos.

1° se editó archivo defs.h1 123 se agregó la función como "int   getprc(void)".
2° se editó archivo syscall.h en la línea 23 definiendo la nueva systemcall con el respectivo número. 
3° se editó archivo user.h y se agregó la systemcall getprc(void) en la línea 26.
4° se editó archivo sysproc.c se agregó la funcion systemcall con en la línea 92
int
sys_getprc(void){
        return getprc();
}
5° se editó el archivo usys.S donde se agregó la systemcall de la función en la línea 32.
SYSCALL(getprc)
6° se editó el archivo syscall.c donde se agregó en la línea 106 "extern int sys_getprc(void)"
y en la línea 130 "[SYS_getprc]  sys_getprc,"
7° se editó el archivo proc.c donde se agregó la actual función en línea 536.

int                           
getprc()
{
        struct proc *p;       
        sti();                
        int cont = 0;         //variable para auxiliar para contar el número de procesos.
        acquire(&ptable.lock);
        for(p =ptable.proc; p < &ptable.proc[NPROC]; p++){ //ciclo para contar.
                if (p->state == RUNNING)                   //condición para contar.
                        cont ++;				     //contando	
        };
        release(&ptable.lock);
        return cont;						     //retornamos el número de procesos

}
8° se creó archivo ps.c para asi tener un programa que llama a la función getprc.
9° Finalmente se editó el archo Makefile para agregar el la aplicacion de usuario ps
se editó en EXTRA línea 255 "ps.c" y en UPROGS línea 168 "_ps"